<?php
die(header("Location: /"));